---
layout: default
title: Hobbies
permalink: /hobbies/
---

Two of my favorite hobbies are astronomy and playing piano. 

<h2 id="astrophotography">Astronomy</h2>

{% assign astro = site.data.astrophotography %}
I enjoy both visual observation through my 8 inch Dobsonian telescope, as well as astrophotography with my computerized setup. All the images are taken by myself, and I also stack and process everything myself. Some of my favorite results are shown below.

{% if astro.equipment and astro.equipment.size > 0 %}
<dl class="spec-list">
{%- for row in astro.equipment %}
  <div><dt>{{ row.label }}</dt><dd>{{ row.value }}</dd></div>
{%- endfor %}
</dl>
{% endif %}

{% if astro.photos and astro.photos.size > 0 %}
<ul class="gallery">
{%- for photo in astro.photos %}
  {%- assign full = photo.image | relative_url -%}
  {%- assign thumb = photo.thumb | default: photo.image | relative_url %}
  <li>
    <a class="gallery-item" href="{{ full }}"
       data-title="{{ photo.title | escape }}"
       data-meta="{% if photo.catalog %}{{ photo.catalog | escape }}{% endif %}{% if photo.date %} · {{ photo.date | date: '%B %Y' }}{% endif %}{% if photo.location %} · {{ photo.location | escape }}{% endif %}"
       data-detail="{% if photo.integration %}Integration: {{ photo.integration | escape }}. {% endif %}{{ photo.notes | escape }}">
      <img src="{{ thumb }}" alt="{{ photo.title | escape }}{% if photo.catalog %} ({{ photo.catalog | escape }}){% endif %}" loading="lazy">
      <span class="gallery-caption">{{ photo.title }}{% if photo.catalog %} <small>{{ photo.catalog }}</small>{% endif %}</span>
    </a>
  </li>
{%- endfor %}
</ul>
{% else %}
<p class="empty-note">Photos coming soon.</p>
{% endif %}

<h2 id="piano">Piano</h2>

{% assign recordings = site.data.piano.recordings %}
I have been playing the piano since I was 6. I take lessons which focus on classical music, but my favorite things to play are arrangements of soundtracks from video games and movies. Here is a performance of a Studio Ghibli medley from about two years ago. 

{% if recordings and recordings.size > 0 %}
<ul class="recordings">
{%- for rec in recordings %}
  <li class="recording">
    <div class="recording-head">
      <h3>{{ rec.title }}</h3>
      <p class="recording-meta">{{ rec.composer }}{% if rec.composer and rec.date %} · {% endif %}{% if rec.date %}{{ rec.date }}{% endif %}</p>
    </div>
    {%- if rec.youtube %}
    <div class="video">
      <button type="button" class="video-facade" data-youtube="{{ rec.youtube | escape }}" aria-label="Play {{ rec.title | escape }} (loads a YouTube video)">
        <img src="https://i.ytimg.com/vi/{{ rec.youtube | escape }}/hqdefault.jpg" alt="" loading="lazy">
        <span class="play-icon" aria-hidden="true"></span>
      </button>
      <noscript><a href="https://www.youtube.com/watch?v={{ rec.youtube | escape }}">Watch on YouTube</a></noscript>
    </div>
    {%- elsif rec.audio %}
    <audio controls preload="none" src="{{ rec.audio | relative_url }}">
      <a href="{{ rec.audio | relative_url }}">Download the recording</a>
    </audio>
    {%- endif %}
    {%- if rec.notes %}
    <p>{{ rec.notes }}</p>
    {%- endif %}
  </li>
{%- endfor %}
</ul>
{% else %}
<p class="empty-note">Recordings coming soon.</p>
{% endif %}

<dialog class="lightbox" aria-label="Photo viewer">
  <form method="dialog"><button class="lightbox-close" aria-label="Close">&times;</button></form>
  <img alt="">
  <div class="lightbox-text">
    <p class="lightbox-title"></p>
    <p class="lightbox-meta"></p>
    <p class="lightbox-detail"></p>
  </div>
</dialog>
