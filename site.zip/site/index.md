---
layout: default
title: Eben Radocchia
hide_title: false
permalink: /
---

<div class="intro">
  <img class="intro-photo" src="{{ site.data.contact.photo }}" alt="Portrait of Eben Radocchia">
  <div markdown="1">

I'm from Bennington, Vermont, and I'm pursuing a B.S. in Electrical Engineering at the University of Vermont, along with the undergraduate certificate in Autonomy and Robotics.

I'm a member of the AERO Club, UVM's Formula SAE Electric team, where I've mainly worked on setting up and configuring the motor controller. In high school I was captain of my local robotics team, FTC-18650, and one of its primary programmers, focusing on autonomous pathing and design. I now mentor the team on software.

<div class="button-row">
  <a class="button" href="{{ site.data.contact.resume }}">Resume (PDF)</a>
  <a class="button button-secondary" href="mailto:{{ site.data.contact.email }}">Email me</a>
</div>

  </div>
</div>

## Projects

{% assign events = site.pages | where: "type", "event" | sort: "date" | reverse %}
<ul class="card-list">
{%- for e in events limit: 4 %}
  {%- include event-card.html event=e %}
{%- endfor %}
</ul>

[All projects &rarr;]({{ '/events/' | relative_url }})

## Other Interests

I'm also into astronomy (visual and photographic) and piano. [See my photos and recordings &rarr;]({{ '/hobbies/' | relative_url }})
