---
layout: default
type: event
title: 8-Key Polyphonic Digital Keyboard
date: 2026-05-06
course: EE 1100A final project
summary: >-
  A pressure-sensitive, polyphonic keyboard built on an Arduino Uno, with
  real-time sine-wave synthesis at 16 kHz, a class-D amplifier, and an OLED
  volume display.
thumbnail: /events/ee1100-polyphonic-keyboard/schematic.png
permalink: /events/ee1100-polyphonic-keyboard/
---

Final project for EE 1100A: EE Principles and Design (Spring 2026), built with Jacob Zilberstein. Instructor: E. Cosoroaba.

## Overview

Commercial keyboards get polyphony and velocity sensitivity from specialized chips, custom key mechanisms, and proprietary firmware. We wanted to see how far we could get with inexpensive, off-the-shelf parts and a standard 8-bit Arduino Uno, about $70 in components.

The finished instrument reads force-sensitive resistors under each key, synthesizes audio in real time, and plays notes individually or as chords. Pressing a key harder makes that note louder in the mix. A potentiometer sets the master volume, an OLED shows the volume level, and an RGB LED shows how many notes are sounding.

The design called for eight keys (C4 to C5) read through a 16-channel analog multiplexer. Unfortunately, unreliable multiplexer breakout boards caused the project showcase to only utilize three keys wired straight to the Arduino's Uno's remaining three analog inputs. Future tests with Arduino's with larger numbers of analog inputs also resulted in greater polyphony. 

## How it works

**Input sensing.** Each key is a popsicle-stick lever with a foam pad that presses on an Adafruit force sensor. Each sensor sits in a voltage divider with a 10 kΩ pulldown. As the press gets firmer, the sensor's resistance falls from over 20 MΩ to about 1 kΩ, and the divider voltage rises. That reading becomes the note's velocity.

**Audio synthesis.** Sound is generated with direct digital synthesis (DDS). A 256-entry, 8-bit sine table lives in flash, and each voice keeps a 16-bit phase accumulator. Timer1 fires an interrupt 16,000 times a second. On each tick, every active voice advances its accumulator by a per-note increment, `Δφ = f_note × 65536 / f_s`. The voice then looks up a sine sample, scales it by velocity, and adds it to the mix. The mix is scaled down by the number of active voices to prevent clipping, then by master volume.

```c
ISR(TIMER1_COMPA_vect) {
  int16_t mix = 0;
  uint8_t activeCount = 0;
  for (uint8_t i = 0; i < NUM_VOICES; i++) {
    if (velocity[i] > 0) {
      accumulator[i] += noteIncrements[i];
      uint8_t index = accumulator[i] >> 8;
      int8_t sample = pgm_read_byte(&sineTable[index]);
      mix += ((int16_t)sample * velocity[i]) >> 8;
      activeCount++;
    }
  }
  mix >>= mixShift[activeCount];
  mix = (mix * volumeFactor) >> 8;
  OCR2A = 128 + mix;
}
```

**Audio output.** Timer2 outputs the mix as PWM on pin 11. A 1 kΩ / 0.01 µF RC low-pass filter (cutoff around 16 kHz) removes the 62.5 kHz PWM carrier. A PAM8403 class-D amplifier on its own 5 V supply then drives the speaker.

**Visual feedback.** A 128×64 I²C OLED shows volume as a number and a bar, refreshed about four times a second so the display doesn't starve the synthesis loop. The RGB LED glows green for one note, blue for two, and red for three or more.

## Schematic

<figure>
  <img src="schematic.png" alt="Circuit schematic: eight force-sensitive resistor dividers feeding a 16-channel multiplexer into an Arduino Uno, with a potentiometer, OLED display, RGB LED, RC filter, and PAM8403 amplifier driving a speaker">
  <figcaption>The full 8-key multiplexer design. The final demo bypasses the multiplexer and wires three sensors directly to the Arduino's analog pins.</figcaption>
</figure>

## Challenges

**Multiplexer signal integrity.** Early readings showed crosstalk: a high reading on one channel bled into the next ones in a descending staircase, because the ADC's sample capacitor held charge between channels. A 1 kΩ pulldown on the signal line, dummy reads, and longer settling delays helped. However, four different breakout boards had intermittent header connections that only worked under pressure, and resoldering didn't fix them. We removed the multiplexer for the final build.

**Amplifier whine.** Digital switching noise coupled through the shared ground into the amplifier as a loud high-pitched whine. It disappeared after we powered the amplifier from a separate 5 V supply, connected the grounds through a 10 kΩ resistor, and added the RC filter.
